#! python3
# Alumni_Registration.py - An Alumni Management Portal for Aluminums of any organization

from platform import system as psys
from os import system as osys
import mysql.connector
from time import sleep

# establishing the connection
conn=mysql.connector.connect(host="localhost",\
user="root",\
passwd="root",\
database="ALUMNI_REGISTRATION")
cur=conn.cursor()

def clearTerminal():
    if psys() == 'Windows':
        osys('cls')
    else:
        osys('clear')

def RegisterAlumni():
    global cur
    clearTerminal()
    print("""
         ____            _     _             _   _             
        |  _ \ ___  __ _(_)___| |_ _ __ __ _| |_(_) ___  _ __  
        | |_) / _ \/ _` | / __| __| '__/ _` | __| |/ _ \| '_ \ 
        |  _ <  __/ (_| | \__ \ |_| | | (_| | |_| | (_) | | | |
        |_| \_\___|\__, |_|___/\__|_|  \__,_|\__|_|\___/|_| |_|
                |___/                                       
        """)
    alumni=[]
    try:
        inputs = ["Name","DOB in YYYY-MM-DD","Gender","E-Mail","Phone No.","Company or Organization",\
                    "Designation","Batch","Branch","Password"]
        for x in inputs:
            i = input(x + ' : ').strip().lower()
            if i == '':
                raise ValueError
            alumni.append(i)

        ID="al"+alumni[0][0:2] + alumni[0][-1:-3]+alumni[4][0:4]
        alumni.insert(0,ID)
        sql="insert into alumni values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        cur.execute(sql,alumni)
        conn.commit()
    except:
        print("Give Valid Inputs . . .")
        return
    print(f"You Have Been Successfully Registered: This is Your AlumniID  #{ID}#,Use This For Further Correspondence")
    osys("@pause")

def YourProfile(user):
    global cur
    clearTerminal()
    print("""
          __   __                 ____             __ _ _      
          \ \ / /__  _   _ _ __  |  _ \ _ __ ___  / _(_) | ___ 
           \ V / _ \| | | | '__| | |_) | '__/ _ \| |_| | |/ _ \ 
            | | (_) | |_| | |    |  __/| | | (_) |  _| | |  __/
            |_|\___/ \__,_|_|    |_|   |_|  \___/|_| |_|_|\___|                                
        """)
    sql = f"SELECT ID, NAME, DOB, GENDER, EMAIL, PHONE_NO, COMPANY, DESIGNATION, BATCH, BRANCH FROM ALUMNI WHERE ID = '{user}';"
    cur.execute(sql)
    res=cur.fetchall()
    res = res[0]

    print(f"""
    ID           :   {res[0]}
    Name         :   {res[1]}
    DOB          :   {res[2]}
    Gender       :   {res[3]}
    E-Mail       :   {res[4]}
    Phone No.    :   {res[5]}
    Company      :   {res[6]}
    Designation  :   {res[7]}
    Batch        :   {res[8]}
    Branch       :   {res[9]}
    """)
    osys("@pause")

def EditProfile(user):
    global cur
    clearTerminal()
    print("""
     _____    _ _ _     ____             __ _ _      
    | ____|__| (_) |_  |  _ \ _ __ ___  / _(_) | ___ 
    |  _| / _` | | __| | |_) | '__/ _ \| |_| | |/ _ \ 
    | |__| (_| | | |_  |  __/| | | (_) |  _| | |  __/
    |_____\__,_|_|\__| |_|   |_|  \___/|_| |_|_|\___|
        """)
    sql = f"select * from alumni where ID = '{user}';"
    cur.execute(sql)
    res = cur.fetchall()[0]
    print(f"""
    Name         :   {res[1]}
    DOB          :   {res[2]}
    Gender       :   {res[3]}
    E-Mail       :   {res[4]}
    Phone No.    :   {res[5]}
    Company      :   {res[6]}
    Designation  :   {res[7]}
    Batch        :   {res[8]}
    Branch       :   {res[9]}
    """)

    fld = input("Enter the field which you want to edit : ").strip().lower()
    val = input("Enter the value you want to set : ").strip().lower()
    try:
        sql = f"Update alumni set {fld} = '{val}' where ID = '{res[0]}';"
        cur.execute(sql)
        conn.commit()
    except:
        print("Give Valid Inputs . . .")
        return
    print("Edited Successfully!")
    sql = f"select * from alumni where ID = '{res[0]}'"
    
    cur.execute(sql)
    res=cur.fetchall()[0]
    print(f"""
    Name         :   {res[1]}
    DOB          :   {res[2]}
    Gender       :   {res[3]}
    E-Mail       :   {res[4]}
    Phone No.    :   {res[5]}
    Company      :   {res[6]}
    Designation  :   {res[7]}
    Batch        :   {res[8]}
    Branch       :   {res[9]}
    """)
    osys("@pause")

def ScheduleEvent():
    global cur
    clearTerminal()
    print("""
     ____       _              _       _        _____                 _   
    / ___|  ___| |__   ___  __| |_   _| | ___  | ____|_   _____ _ __ | |_ 
    \___ \ / __| '_ \ / _ \/ _` | | | | |/ _ \ |  _| \ \ / / _ \ '_ \| __|
    ___)  | (__| | | |  __/ (_| | |_| | |  __/ | |___ \ V /  __/ | | | |_ 
    |____/ \___|_| |_|\___|\__,_|\__,_|_|\___| |_____| \_/ \___|_| |_|\__|
        """)
    Events = []
    inputs = ['Event Name to Schedule','Event Date in YYYY-MM-DD','Event Venue', 'Event Status [Completed or Not Completed]']
    for x in inputs:
        i = input(x + ' : ').strip().lower()
        Events.append(i)
    
    sql = "insert into event values (%s,%s,%s,%s)"
    try:
        cur.execute(sql,Events)
        conn.commit()
    except:
        print("Give Valid Inpunts...")
    print("You have Scheduled an Event")
    osys("@pause")

def ViewEventDetails():
    global cur
    clearTerminal()
    print("""
    __     ___                 _____                 _       
    \ \   / (_) _____      __ | ____|_   _____ _ __ | |_ ___ 
     \ \ / /| |/ _ \ \ /\ / / |  _| \ \ / / _ \ '_ \| __/ __|
      \ V / | |  __/\ V  V /  | |___ \ V /  __/ | | | |_\__ \
       \_/  |_|\___| \_/\_/   |_____| \_/ \___|_| |_|\__|___/
        """)
    try:
        cur.execute("SELECT EVENT_NAME FROM EVENT;")
        events = {}
        events_data = cur.fetchall()
        if events_data == []:
            print("There are no events scheduled at the moment.")
            osys("@pause")
            return
        
        for i in range(0, len(events_data)):
            print(f"{i + 1} {events_data[i][0]}")
            events.setdefault('')
            events[i + 1] = events_data[i][0]
        ch = int(input("Choose an event to view its details:(enter its serial number)  ").strip())
    except ValueError:
        print("Give Valid Inputs")
        return
    sql = f"SELECT * FROM EVENT WHERE EVENT_NAME = '{events[ch]}'"
    cur.execute(sql)
    res = cur.fetchall()[0]
    
    print(f"""
    Event_Name : {res[0]}
    Event_Date : {res[1]}
    Venue      : {res[2]}
    Status     : {res[3]}
    """)
    osys("@pause")
    
def DeleteEvent():
    global cur
    clearTerminal()
    print("""
         ____       _      _         _____                 _       
        |  _ \  ___| | ___| |_ ___  | ____|_   _____ _ __ | |_ ___ 
        | | | |/ _ \ |/ _ \ __/ _ \ |  _| \ \ / / _ \ '_ \| __/ __|
        | |_| |  __/ |  __/ ||  __/ | |___ \ V /  __/ | | | |_\__ \ 
        |____/ \___|_|\___|\__\___| |_____| \_/ \___|_| |_|\__|___/
        """)
    cur.execute("SELECT * FROM EVENT")
    if cur.fetchall() == []:
        print("There are no events to delete.")
        osys("@pause")
        return
    else:
        try:
            ename=input("Enter the Event Name to be deleted : ").strip().lower()
            confirmation = input("Are you sure? [Y/N] ").strip().upper()
            if confirmation == '': raise ValueError
            if confirmation == 'Y':
                sql=f"Delete from event where event_name = '{ename}'"
                cur.execute(sql)
                conn.commit()
                print("Record Deleted :)")
            elif confirmation == 'N': return
            else : print("Choose between Y or N")
        except ValueError:
            print("Give Input Input")
        osys("@pause")

def Portal(user):
    while True:
        clearTerminal()
        print("""
         ____            _        _ 
        |  _ \ ___  _ __| |_ __ _| |
        | |_) / _ \| '__| __/ _` | |
        |  __/ (_) | |  | || (_| | |
        |_|   \___/|_|   \__\__,_|_|
            """)
        print("Enter 1       :       To View Your Profile")
        print("Enter 2       :       To Edit Your Profile")
        print("Enter 3       :       To Schedule an Event")
        print("Enter 4       :       To View an Event")
        print("Enter 5       :       To Delete an Event")
        print("Enter 6       :       To Sign Out")

        try:
            userInput = int(input("Select One of the Options: ").strip())
        except ValueError:
            print("Give Valid Inputs ...")
            continue
        else:
            print("\n")
        if (userInput == 1):
            YourProfile(user)
        elif (userInput== 2):
            EditProfile(user)
        elif (userInput== 3):    
            ScheduleEvent()
        elif (userInput== 4):
            ViewEventDetails()
        elif (userInput== 5):
            DeleteEvent()
        elif (userInput == 6):
            print("Signing Out ...")
            sleep(0.5)
            return

def LoginMenu():
    global cur
    clearTerminal()
    print(""" 
         _                _       
        | |    ___   __ _(_)_ __  
        | |   / _ \ / _` | | '_ \ 
        | |__| (_) | (_| | | | | |
        |_____\___/ \__, |_|_| |_|
                    |___/         
        """)
    userID = input("UserID: ").strip()
    password = input("Password: ").strip()
    if (userID or password) == '':
        print("UserID or password not entered.")
    sql = f"SELECT ID, PASSWORD FROM ALUMNI WHERE ID = '{userID}'"
    cur.execute(sql)
    data = cur.fetchone()
    if data == None:
        print("This UserID is not registered.")
        clearTerminal()
        LoginMenu()
    elif data[1] == password:
        print("Logging In...")
        sleep(0.5)
        Portal(userID)
    elif data[1] != password:
        print("Wrong Password.")
        clearTerminal()
        LoginMenu()

if __name__ == '__main__':
    while True:
        clearTerminal()
        print("""
            _    _                       _ 
           / \  | |_   _ _ __ ___  _ __ (_)
          / _ \ | | | | | '_ ` _ \| '_ \| |
         / ___ \| | |_| | | | | | | | | | |
        /_/   \_\_|\__,_|_| |_| |_|_| |_|_|
                                   
         ____            _               _   _             
        |  _ \ ___  __ _(_)___ _ __ __ _| |_(_) ___  _ __  
        | |_) / _ \/ _` | / __| '__/ _` | __| |/ _ \| '_ \ 
        |  _ <  __/ (_| | \__ \ | | (_| | |_| | (_) | | | |
        |_| \_\___|\__, |_|___/_|  \__,_|\__|_|\___/|_| |_|
                    |___/                
        """)
        print("1 : SignIn to an existing account")
        print("2 : SignUp to a new account")
        print("3 : to exit the program")
        usr_input = input('Choose from the above options : ')
        if usr_input == '1':
            LoginMenu()
        elif usr_input == '2':
            osys('cls')
            RegisterAlumni()
        elif usr_input == '3':
            quit()
        else:
            print("Choose from the above options!")
            osys("@pause")
